#include <iostream>
#include <fstream>
#include <algorithm>
#include <queue>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <string.h>
using namespace std;

#define VertexMaxSize 3000
#define EdgeMaxSize 24000
#define PopulationSize 150  // Number of population
#define CrossoverRate 0.85   // Probablity of crossover
#define MutateRate 0.1     // Probablity of mutation
#define ReplaceRate 0.95     // Probablity of replacement

int vertex, edges;      // vertex, edge
int bestcut = 0;       // store the best cut value of population
int worstcut = 0;      // store the worst cut value of population
float allFit = 0;
int limitCut;
int timeStamp = 50;
int matrix[VertexMaxSize][VertexMaxSize] = { 0 };
int skip_count = 0;
string inputFile = "maxcut.in";

struct Edge
{
    int startIndex;
    int endIndex;
    int weight;
};
struct Edge edgelist[EdgeMaxSize + 1];

struct Genotype
{
    int cut;           // Cut value
    float fitness;     // Fi = (Cw-Ci) + (Cw-Cb)/(k-1)
    int gene[VertexMaxSize];     // store points which belongs to S set
    int localImpossible = 0;

    Genotype() {
        memset(gene, 0, sizeof(gene));
    }

    void printGene() {
        ofstream SaveFile("maxcut.out");
        for (int i = 0; i < vertex; i++)
        {
            if (gene[i] == 1) {
                SaveFile << i + 1 << " ";
            }
        }
        SaveFile << endl;
        SaveFile.close();
    }
};
Genotype best;
struct Genotype population[PopulationSize + 1];

void makeRandomSet(int index);
void init(string inputFile);
int calCut(Genotype GT);
void UpdateGroupValue();
float calFit(Genotype GT);
void handleMaxcut();
int selectIndex(Genotype Pop[PopulationSize + 1]);
void crossover(Genotype *P1, Genotype *P2, Genotype *C1, Genotype *C2);
int localOptimization(int index);
int updateCut(Genotype GT, int index, int after_bit);
int mutation(int index, float mRate);
void replace();

int main() {
    init(inputFile);
    handleMaxcut();
}

void init(string inputFile) {
    int from, to, weight;
    ifstream input;
    input.open(inputFile.c_str());
    srand((unsigned)time(NULL));

    if (!input) { // File check
        cout << "Can not read input file, please check the input filename again\n";
        exit(1);
    }

    input >> vertex >> edges;

    cout << "vertex is :" << vertex << endl;
    cout << "edge is :" << edges << endl;

    if (vertex < 2)  //Vertex number check
        cout << "Can not crossover, please modify vertex number bigger than 2" << endl;

    for (int i = 0; i < edges; i++) {
        input >> from >> to >> weight;
        edgelist[i].startIndex  = from - 1;
        edgelist[i].endIndex    = to - 1;
        edgelist[i].weight      = weight;
        matrix[from - 1][to - 1] = weight;
        matrix[to - 1][from - 1] = weight;
    }

    for (int i = 0; i < PopulationSize; i++) {
        makeRandomSet(i);
        if (i == 0) {
            bestcut = population[i].cut;
            best = population[i];
        } else {
            if (population[i].cut > bestcut) {
                bestcut = population[i].cut;
                best = population[i];
            }
            if (population[i].cut < worstcut)
                worstcut = population[i].cut;
        }
    }

    UpdateGroupValue();
    cout << endl;
    cout << "Initial Generation: bestcut is: " << bestcut << endl;
}

void handleMaxcut() {
    clock_t start, end;
    int fatherIndex, motherIndex;
    Genotype child1, child2;
    start = clock();

    while (1) {
        end = clock();
        if (end - start > 300 * CLOCKS_PER_SEC) {
            cout << "bestcut is " << bestcut << endl;
            break;
        }

        for (int i = 0; i < PopulationSize; ++i) {
            fatherIndex = selectIndex(population);
            motherIndex = selectIndex(population);

            if (rand() % 10 < 10 * CrossoverRate) {
                memcpy(&child1, &population[fatherIndex], sizeof(Genotype));
                memcpy(&child2, &population[motherIndex], sizeof(Genotype));

                crossover(&population[fatherIndex], &population[motherIndex], &child1, &child2);

                if (child1.cut > population[fatherIndex].cut || child1.cut > population[motherIndex].cut) {
                    child1.localImpossible = 0;
                    if (population[fatherIndex].cut < population[motherIndex].cut) {
                        memcpy(&population[fatherIndex], &child1, sizeof(Genotype));
                    } else {
                        memcpy(&population[motherIndex], &child1, sizeof(Genotype));
                    }
                    if (bestcut < child1.cut) {
                        bestcut = child1.cut;
                        best = child1;
                        cout << "From crossover: best cut is: " << bestcut << endl;
                    }
                }
                if (child2.cut > population[fatherIndex].cut || child2.cut > population[motherIndex].cut) {
                    child2.localImpossible = 0;
                    if (population[fatherIndex].cut < population[motherIndex].cut) {
                        memcpy(&population[fatherIndex], &child2, sizeof(Genotype));
                    } else {
                        memcpy(&population[motherIndex], &child2, sizeof(Genotype));
                    }
                    if (bestcut < child2.cut) {
                        bestcut = child2.cut;
                        best = child2;
                        cout << "From crossover: best cut is: " << bestcut << endl;
                    }
                }
            }
        }
        for (int i = 0; i < PopulationSize; i++) {
            mutation(i, MutateRate);
        }

        int delta = (int)(end - start);
        int now = delta / CLOCKS_PER_SEC;
        if (now >= timeStamp) {
            cout << "restart" << endl;
            replace();
            timeStamp = timeStamp + 60;
        } else {
            for (int i = 0; i < PopulationSize; i++) {
                int res = localOptimization(i);
            }
        }
        UpdateGroupValue();
    }
    cout << "5 min finish" << endl;
}

int mutation(int index, float mRate)   //mutationRate = 1, delete bad mutation individual
{
    int num = mRate * 100;
    int changed = 0;
    for (int k = 0; k < vertex; k++) {
        if (rand() % 100 < num) {
            population[index].gene[k] = 1 - population[index].gene[k];
            //	int cut = calCut(population[index]);
            int cut = updateCut(population[index], k, population[index].gene[k]);

            if (cut > population[index].cut) {
                if (bestcut < cut) {
                    int dec = rand() % 100;
                    if (dec < 98) {
                        bestcut = cut;
                        best = population[index];
                        population[index].cut = cut;
                        cout << "From mutation: best cut is: " << bestcut << endl;
                        best.printGene();
                    }
                }
                population[index].cut = cut;
                changed = 1;
            } else {
                population[index].gene[k] = 1 - population[index].gene[k];
                changed = 0;
            }
        }
    }
    return changed;
}

int localOptimization(int index) {
    int cut;
 //   int select;
    int array[VertexMaxSize];
    int change = 0;

    if (population[index].localImpossible && population[index].cut != bestcut) {
        int maybe = 8;
        if (population[index].cut < bestcut && maybe > rand() % 10) {
            makeRandomSet(index);
        }
        return 1;
    }
    for (int i = 0; i < vertex; i++) {
        array[i] = i;
    }
    for (int i = 0; i < vertex; i++) {
        int temp1 = rand() % vertex;
        int temp2 = rand() % vertex;
        if (temp1 != temp2) {
            int temp = array[temp1];
            array[temp1] = array[temp2];
            array[temp2] = temp;
        }
    }

    for (int i = 0; i < vertex; i++) {
        if (1) {
            population[index].gene[array[i]] = 1 - population[index].gene[array[i]];
            cut = updateCut(population[index], array[i], population[index].gene[array[i]]);

            if (cut > population[index].cut) {
                if (cut > bestcut) {
                    bestcut = cut;
                    best = population[index];
                    cout << "From local search(1-bit): best cut is: " << bestcut << endl;
                    best.printGene();
                }
                population[index].cut = cut;
                change = 1;
            } else {
                population[index].gene[array[i]] = 1 - population[index].gene[array[i]];
            }
        }
    }
    if (!change) {
        population[index].localImpossible = 1;
    }
    return 0;
}

void replace() {
    for (int i = 0; i < PopulationSize; i++) {
        if (population[i].cut < bestcut * ReplaceRate) 
            makeRandomSet(i);

        if (i == 0) {
              worstcut = population[i].cut;
        } else {
            if (population[i].cut > bestcut) {
                bestcut = population[i].cut;
                best = population[i];
            }
            if (population[i].cut < worstcut)
                worstcut = population[i].cut;
        }
    }
}


int updateCut(Genotype GT, int index, int after_bit) {
    int result = GT.cut;
    for (int i = 0; i < vertex; i++) {
        if (matrix[index][i] != 0) {
            if (GT.gene[i] != after_bit)
                result += matrix[index][i];
            else
                result -= matrix[index][i];
        }
    }
    return result;
}

void crossover(Genotype *P1, Genotype *P2, Genotype *C1, Genotype *C2) {
    int sum = 0, temp;
    int num = rand() % vertex;

    for (int i = 0; i < num; i++) {
        C1->gene[i] = P1->gene[i];
        C2->gene[i] = P2->gene[i];
    }
    for (int i = num; i < vertex; i++) {
        C1->gene[i] = P2->gene[i];
        C2->gene[i] = P1->gene[i];
    }
    C1->cut = calCut(*C1);
    C2->cut = calCut(*C2);
}

int selectIndex(Genotype Pop[PopulationSize + 1]) {
    int sum = 0;
    int ranNum = -rand() % (int)(allFit);

    for (int i = 0; i < PopulationSize; i++) {
        if (sum < ranNum) {
            return i;
        }
        sum += Pop[i].fitness;
    }
    return PopulationSize - 1;
}

void UpdateGroupValue()
{
    allFit = 0;  //reset allfit
    for (int i = 0; i < PopulationSize; i++) {
        population[i].fitness = calFit(population[i]);
        allFit = allFit + population[i].fitness;
//        cout << population[i].fitness << endl;
    }
}

float calFit(Genotype GT)
{
    float result;
    float fixedValue = 1.0 * (worstcut - bestcut) / (PopulationSize - 1);
    result = (worstcut - GT.cut) + fixedValue;
    return result;
}

void makeRandomSet(int index) {
    //p = 0.3, 0.5, 0.7
    int num = rand() % 3;
//    population[index].gene[0] = 1;
    if (num == 0) {
        for (int i = 0; i < vertex; i++) {
            int temp = rand() % 10;
            population[index].gene[i] = temp < 3 ? 1 : 0;
        }
    } else if (num == 1) {
        for (int i = 0; i < vertex; i++) {
            int temp = rand() % 10;
            population[index].gene[i] = temp < 5 ? 1 : 0;
        }
    } else if (num == 2) {
        for (int i = 0; i < vertex; i++) {
            int temp = rand() % 10;
            population[index].gene[i] = temp < 7 ? 1 : 0;
        }
    }
    population[index].cut = calCut(population[index]);
//    cout << population[index].cut << endl;
//    cout << population[index].localImpossible << endl;
}

int calCut(Genotype GT) {
    int cutValue = 0, index1, index2;
    for (int i = 0; i < edges; i++)
    {
        index1 = edgelist[i].startIndex;
        index2 = edgelist[i].endIndex;
        if (GT.gene[index1] != GT.gene[index2]) {
            cutValue += edgelist[i].weight;
        }
    }
    return cutValue;
}